package br.com.matheus.candido.Layout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Cadastro_activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_activity)
    }
}
