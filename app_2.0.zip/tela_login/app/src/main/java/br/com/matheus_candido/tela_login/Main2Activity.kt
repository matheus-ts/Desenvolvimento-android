package br.com.matheus_candido.tela_login

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        //Criando a preferencia
        val minhaPreferencia = getSharedPreferences("cadastro", Context.MODE_PRIVATE);

        val nomeAluno = minhaPreferencia.getString("nome","Erro Preference")
        val sobreAluno = minhaPreferencia.getString("sobrenome","Erro Preference")
        val emailAluno = minhaPreferencia.getString("email","Erro Preference")
        val sexoAluno = minhaPreferencia.getString("sexo","Erro Preference")

        txNome.text =  "$nomeAluno $sobreAluno";
            txEmail.text = emailAluno;
                txSexo.text = sexoAluno;


        btnSair.setOnClickListener {
            startActivity(Intent(this@Main2Activity, MainActivity::class.java))
            finishAffinity()
        }
        btnWeb.setOnClickListener {
            startActivity(Intent(this@Main2Activity, WebActivity::class.java))
            finishAffinity()
        }
    }
}
