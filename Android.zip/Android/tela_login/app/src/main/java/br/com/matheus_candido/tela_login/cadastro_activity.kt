package br.com.matheus_candido.tela_login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class cadastro_activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro_activity)
    }
}
